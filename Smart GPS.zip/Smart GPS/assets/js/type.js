// window.ityped.init(document.querySelector('.ityped'),{
//     strings: [' Security.'],
//     typeSpeed: 140,
//     backSpeed: 140,
//     loop: true
// })
// document.getElementsByTagName("h1")[0].style.fontSize = "70px";